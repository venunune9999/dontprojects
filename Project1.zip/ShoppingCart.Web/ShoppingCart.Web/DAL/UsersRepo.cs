﻿using ShoppingCart.Web.Models;

namespace ShoppingCart.Web.DAL
{
    public class UsersRepo
    {
        private readonly CartDBContext _cartDBContext;

        public UsersRepo(CartDBContext cartDBContext)
        {
            _cartDBContext = cartDBContext;
        }

        public bool AddUser(User user )
        {
            try
            {
                //user.Roleid = 2;
                _cartDBContext.Users.Add(user);
                _cartDBContext.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }
    }
}
