﻿using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Web.BAL;
using ShoppingCart.Web.DAL;
using ShoppingCart.Web.Models;

namespace ShoppingCart.Web.Controllers
{
    public class UserController : Controller
    {
        private readonly CartDBContext _cartDBContext;
        public UserController(CartDBContext cartDBContext) { 
        
            _cartDBContext = cartDBContext;
        }
        public IActionResult Registration()
        {
            UserVM userVM = new UserVM();

            return View("SignUP",userVM);
        }

        [HttpPost]
        public IActionResult UserSignUP(UserVM userVM)
        {
            if(ModelState.IsValid)
            {
                // Insert to DB.
                UserBAL userBAL = new UserBAL(_cartDBContext);
                if(userBAL.InsertUser(userVM))
                {
                    TempData["user"] = userVM.Firstname +" "+ userVM.Lastname;
                    return RedirectToAction("Index", "Cart");
                }
            }

            return View("SignUP", userVM);
        }
    }
}
