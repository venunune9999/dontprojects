﻿namespace ShoppingCart.Web.DAL
{
    public class ProductRepo
    {
    }
}
